default_app_config = "apps.api.{{ app_name }}.apps.{{ camel_case_app_name }}Config"
