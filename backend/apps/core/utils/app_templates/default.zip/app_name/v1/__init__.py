# flake8: noqa
from .routers import urlpatterns, app_name
