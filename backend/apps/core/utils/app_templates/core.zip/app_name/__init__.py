default_app_config = "apps.core.{{ app_name }}.apps.{{ camel_case_app_name }}Config"
